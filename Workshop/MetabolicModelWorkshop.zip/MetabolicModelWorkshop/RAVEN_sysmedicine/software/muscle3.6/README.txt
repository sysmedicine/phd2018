README for MUSCLE download
--------------------------

The archive includes these files:

	README.txt
	LICENSE.txt
	muscle (Linux) or muscle.exe (Windows)
	seqs.fa

The documentation is available as a separate download
or can be browsed on the web at the MUSCLE site:

	http://www.drive5.com/muscle

There are no configuration files, environment variables
or other setup issues -- to install, just copy the
executable to a directory that is accessible from
your computer. On Linux, the executable is named
muscle, on Windows it is named muscle.exe.
